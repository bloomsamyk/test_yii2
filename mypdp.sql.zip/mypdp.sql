-- phpMyAdmin SQL Dump
-- version 4.5.4.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 04, 2016 at 05:50 PM
-- Server version: 5.7.11-log
-- PHP Version: 7.0.3RC1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mypdp`
--

-- --------------------------------------------------------

--
-- Table structure for table `articles`
--

CREATE TABLE `articles` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` varchar(255) NOT NULL DEFAULT '',
  `user_id` int(11) NOT NULL,
  `cat_id` int(11) NOT NULL,
  `status` enum('empty','in progress','done') NOT NULL DEFAULT 'empty',
  `level` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `articles`
--

INSERT INTO `articles` (`id`, `name`, `description`, `user_id`, `cat_id`, `status`, `level`) VALUES
(1, 'Memory heap, stack', '', 1, 1, 'empty', 2),
(2, 'BSS, Data segments', '', 1, 1, 'empty', 2),
(3, 'Virtual Memory Allocation', '', 1, 1, 'empty', 2),
(4, 'Threads and Processes', '', 1, 1, 'empty', 2),
(5, 'Array Data Structure', '', 1, 2, 'empty', 1),
(6, 'Recursion general awareness', '', 1, 2, 'empty', 1),
(7, 'Linked list', '', 1, 2, 'empty', 2),
(8, 'Queue data structure', '', 1, 2, 'empty', 2),
(9, 'Stack data structure', '', 1, 2, 'empty', 2),
(10, 'Hash Table (basic explanation)', '', 1, 2, 'empty', 2),
(11, 'Buble sort', '', 1, 2, 'empty', 2),
(12, 'Insersion sort', '', 1, 2, 'empty', 2),
(13, 'Binary search', '', 1, 2, 'empty', 2),
(14, 'Recursion Pros and Cons', '', 1, 2, 'empty', 3),
(15, 'Recursion optimization (Tail recursion)', '', 1, 2, 'empty', 3),
(16, 'Dynamic arrays and memory allocation', '', 1, 2, 'empty', 3),
(17, 'Linked list Pros and Cons', '', 1, 2, 'empty', 3),
(18, 'persistent data structures', '', 1, 2, 'empty', 3),
(19, 'Hash table implementation, protection against colisions', '', 1, 2, 'empty', 3),
(20, 'Tree data structure', '', 1, 2, 'empty', 3),
(21, 'Heap data structure', '', 1, 2, 'empty', 3),
(22, 'Quick sort', '', 1, 2, 'empty', 3),
(23, 'Merge sort', '', 1, 2, 'empty', 3),
(24, 'Understanding algorithm complexity', '', 1, 2, 'empty', 3),
(25, 'persistent queue', '', 1, 2, 'empty', 4),
(26, 'persistent stack', '', 1, 2, 'empty', 4),
(27, 'Graph data structure', '', 1, 2, 'empty', 4),
(28, 'Basic Graph algirithms (BFS, DFS, Dijkstra\'s)', '', 1, 2, 'empty', 4),
(29, 'Dutch national flag problem, Quick sort degradation,', '', 1, 2, 'empty', 4),
(30, 'Map-reduce', '', 1, 2, 'empty', 4),
(31, 'Divide-and-Conquer', '', 1, 2, 'empty', 4),
(32, 'Functional programming fundamentials', '', 1, 3, 'empty', 1),
(33, 'OOP fundamentals', '', 1, 3, 'empty', 1),
(34, 'Code reuse/DRY principle', '', 1, 3, 'empty', 1),
(35, 'Patterns general awareness (general groups)', '', 1, 3, 'empty', 1),
(36, 'Basic patterns', '', 1, 3, 'empty', 1),
(37, 'Anonymous (lambda) functions', '', 1, 3, 'empty', 2),
(38, 'S.O.L.I.D. principles', '', 1, 3, 'empty', 2),
(39, 'Can explain at least 2 (from 4 asked) Creational patterns', '', 1, 3, 'empty', 2),
(40, 'Can explain at least 1 (from 3 asked) Structural patterns', '', 1, 3, 'empty', 2),
(41, 'Can explain at least 1 (from 2 asked) Behavioral pattenrs', '', 1, 3, 'empty', 2),
(42, 'Anti-patterns general awareness', '', 1, 3, 'empty', 2),
(43, 'Closures', '', 1, 3, 'empty', 3),
(44, 'Complexity reducing techniques (in software design context)', '', 1, 3, 'empty', 3),
(45, 'Can explain at least 4 (from 4 asked) Creational patterns', '', 1, 3, 'empty', 3),
(46, 'Can explain at least 3 from 4 Structural patterns', '', 1, 3, 'empty', 3),
(47, 'Can explain 2 (from 3 asked) Behavioral patterns', '', 1, 3, 'empty', 3),
(48, 'Lazy evaluation', '', 1, 3, 'empty', 4),
(49, 'Aspect oriented programming', '', 1, 3, 'empty', 4),
(50, 'Demonstrates rock solid knowlage in design patterns field', '', 1, 3, 'empty', 4);

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `name`) VALUES
(1, 'Web Development General Skills: Memory Management'),
(2, 'Development General Skills: Data structures/Basic algorithms'),
(3, 'Development General Skills: Programming paradigms, software design patterns, principles and techniques'),
(4, 'Development General Skills: Architectural styles/Patterns of enterprise application architecture and integration'),
(5, 'Development General Skills: Network/Communications'),
(6, 'Development General Skills: Databases'),
(7, 'Development General Skills: Markup'),
(8, 'Development General Skills: Security'),
(9, 'Development General Skills: Testing and refactoring'),
(10, 'Development General Skills: Optimization, Highload'),
(11, 'PHP');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `login` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `salt` varchar(100) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `adress` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `login`, `email`, `password`, `salt`, `phone`, `adress`) VALUES
(1, 'admin', 'admin', 'admin', 'admin', '', '', ''),
(2, 'demo', 'demo', 'demo', 'demo', 'demo', 'demo', 'demo');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `articles`
--
ALTER TABLE `articles`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `cat_id` (`cat_id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `articles`
--
ALTER TABLE `articles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;
--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `articles`
--
ALTER TABLE `articles`
  ADD CONSTRAINT `articles_ibfk_1` FOREIGN KEY (`cat_id`) REFERENCES `category` (`id`),
  ADD CONSTRAINT `items_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
